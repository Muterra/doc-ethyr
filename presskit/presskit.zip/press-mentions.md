# Press mentions

+ [AWS podcast interview with Jeff Barr](https://aws.amazon.com/de/podcasts/aws-podcast/). Episode #120, direct link to mp3: http://d3bq93zls2dba9.cloudfront.net/AWS_Podcast_120.mp3